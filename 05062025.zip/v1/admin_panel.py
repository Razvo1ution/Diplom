import sys
import calendar
from datetime import date
from PyQt5.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                             QListWidget, QPushButton, QLabel, QTextEdit,
                             QMessageBox, QDialog, QLineEdit, QFormLayout,
                             QDialogButtonBox, QListWidgetItem, QComboBox, QGroupBox,
                             QTableWidget, QTableWidgetItem, QHeaderView)
from PyQt5.QtGui import QFont, QColor
from PyQt5.QtCore import Qt
import database
from auth import AddTeamDeveloperDialog

class AdminPanel(QMainWindow):
    def __init__(self, user_data):
        super().__init__()
        self.user_data = user_data
        self.selected_developer = None
        self.setWindowTitle(f'Панель администратора: {self.user_data["username"]}')
        self.setGeometry(100, 100, 900, 700)
        self.init_ui()
        self.load_team_developers()

    def init_ui(self):
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        main_layout = QHBoxLayout(main_widget)
        
        left_layout = QVBoxLayout()
        left_layout.addWidget(QLabel("Команда:"))
        self.team_list = QListWidget()
        self.team_list.itemClicked.connect(self.on_developer_selected)
        left_layout.addWidget(self.team_list)
        
        self.add_dev_button = QPushButton("Добавить разработчика")
        self.add_dev_button.clicked.connect(self.add_team_developer)
        left_layout.addWidget(self.add_dev_button)
        
        right_layout = QVBoxLayout()
        
        filter_layout = QHBoxLayout()
        self.year_selector = QComboBox()
        self.month_selector = QComboBox()
        self.day_selector = QComboBox()
        self.filter_button = QPushButton("Показать")
        
        filter_layout.addWidget(QLabel("Год:"))
        filter_layout.addWidget(self.year_selector)
        filter_layout.addWidget(QLabel("Месяц:"))
        filter_layout.addWidget(self.month_selector)
        filter_layout.addWidget(QLabel("День:"))
        filter_layout.addWidget(self.day_selector)
        filter_layout.addWidget(self.filter_button)
        right_layout.addLayout(filter_layout)

        daily_group = QGroupBox("Ежедневная активность")
        daily_layout = QVBoxLayout()
        self.daily_metrics_display = QTextEdit()
        self.daily_metrics_display.setReadOnly(True)
        self.daily_metrics_display.setFixedHeight(100)
        daily_layout.addWidget(self.daily_metrics_display)
        daily_group.setLayout(daily_layout)
        right_layout.addWidget(daily_group)

        code_group = QGroupBox("Изменения в коде")
        code_layout = QVBoxLayout()
        self.code_changes_table = QTableWidget()
        self.code_changes_table.setColumnCount(3)
        self.code_changes_table.setHorizontalHeaderLabels(["Файл", "Добавлено", "Удалено"])
        header = self.code_changes_table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.Stretch)
        header.setSectionResizeMode(1, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(2, QHeaderView.ResizeToContents)
        self.code_changes_table.setEditTriggers(QTableWidget.NoEditTriggers)
        code_layout.addWidget(self.code_changes_table)
        code_group.setLayout(code_layout)
        right_layout.addWidget(code_group)
        
        main_layout.addLayout(left_layout, 2)
        main_layout.addLayout(right_layout, 5)

        self.year_selector.currentIndexChanged.connect(self.update_day_selector)
        self.month_selector.currentIndexChanged.connect(self.update_day_selector)
        self.filter_button.clicked.connect(self.display_filtered_metrics)

        self.month_selector.addItems([calendar.month_name[i] for i in range(1, 13)])

    def on_developer_selected(self, item):
        dev_data = item.data(Qt.UserRole)
        if not dev_data:
            return
        self.selected_developer = dev_data
        self.daily_metrics_display.setText(f"Выберите дату для просмотра метрик для {self.selected_developer['username']}.")
        self.code_changes_table.setRowCount(0)
        self.populate_year_selector()

    def display_filtered_metrics(self):
        if not self.selected_developer:
            QMessageBox.warning(self, "Ошибка", "Сначала выберите разработчика.")
            return
        
        try:
            year = int(self.year_selector.currentText())
            month = self.month_selector.currentIndex() + 1
            day = int(self.day_selector.currentText())
            selected_date = date(year, month, day)
        except (ValueError, IndexError):
            QMessageBox.warning(self, "Ошибка", "Пожалуйста, выберите корректную дату.")
            return

        self.daily_metrics_display.setText(f"Загрузка метрик для {self.selected_developer['username']} на {selected_date.strftime('%d.%m.%Y')}...")
        self.code_changes_table.setRowCount(0)

        metrics = database.get_metrics_for_user_on_date(self.selected_developer['id'], selected_date)
        
        self.populate_daily_metrics(metrics.get('daily'))
        self.populate_code_changes_table(metrics.get('code'))

        if not metrics.get('daily') and not metrics.get('code'):
            self.daily_metrics_display.setText(f"Нет данных для разработчика {self.selected_developer['username']} на {selected_date.strftime('%d.%m.%Y')}")

    def populate_daily_metrics(self, daily_data):
        if daily_data:
            total_time_str = f"{daily_data.get('total_time', 0):.2f}ч"
            text = (f"Время работы: {total_time_str}\n"
                    f"Коммитов за день: {daily_data.get('commits', 0)}\n"
                    f"Ночные коммиты: {daily_data.get('night_commits', 0)}")
            self.daily_metrics_display.setText(text)
        else:
            self.daily_metrics_display.setText("Нет данных о дневной активности на эту дату.")
    
    def populate_code_changes_table(self, code_changes_data):
        self.code_changes_table.setRowCount(0)
        if not code_changes_data:
            return

        self.code_changes_table.setRowCount(len(code_changes_data))
        for row_idx, change in enumerate(code_changes_data):
            file_path = change.get('file', 'N/A')
            added_str = f"+{change.get('added', 0)}"
            removed_str = f"-{change.get('removed', 0)}"

            file_item = QTableWidgetItem(file_path)
            added_item = QTableWidgetItem(added_str)
            removed_item = QTableWidgetItem(removed_str)

            added_item.setForeground(QColor('green'))
            added_item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            removed_item.setForeground(QColor('red'))
            removed_item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            
            self.code_changes_table.setItem(row_idx, 0, file_item)
            self.code_changes_table.setItem(row_idx, 1, added_item)
            self.code_changes_table.setItem(row_idx, 2, removed_item)

    def load_team_developers(self):
        self.team_list.clear()
        team = database.get_team_by_admin(self.user_data['id'])
        if not team:
            self.team_list.addItem("У вас пока нет разработчиков.")
            return

        for dev in team:
            item_text = f"{dev['full_name']} ({dev['username']})"
            list_item = QListWidgetItem(item_text)
            list_item.setData(Qt.UserRole, dev)
            self.team_list.addItem(list_item)
        
    def populate_year_selector(self):
        self.year_selector.clear()
        if not self.selected_developer:
            return
        years = database.get_available_years_for_user(self.selected_developer['id'])
        if years:
            self.year_selector.addItems([str(y) for y in years])
        else:
            self.year_selector.addItem(str(date.today().year))

    def update_day_selector(self):
        try:
            year = int(self.year_selector.currentText())
            month = self.month_selector.currentIndex() + 1
        except (ValueError, IndexError):
            return

        _, num_days = calendar.monthrange(year, month)
        
        current_day = self.day_selector.currentText()
        self.day_selector.clear()
        self.day_selector.addItems([str(d) for d in range(1, num_days + 1)])
        
        if current_day and int(current_day) <= num_days:
            self.day_selector.setCurrentText(current_day)

    def add_team_developer(self):
        dialog = AddTeamDeveloperDialog(self)
        if dialog.exec_() == QDialog.Accepted:
            data = dialog.get_data()
            if not all(data.values()):
                QMessageBox.warning(self, "Ошибка", "Все поля должны быть заполнены.")
                return
            
            user_id = database.create_user(
                full_name=data["full_name"],
                email=None,
                username=data["username"],
                password=data["password"],
                role="Team Developer",
                admin_id=self.user_data['id']
            )
            
            if user_id:
                QMessageBox.information(self, "Успех", f"Разработчик {data['username']} добавлен.")
                self.load_team_developers()
            else:
                QMessageBox.warning(self, "Ошибка", "Не удалось добавить разработчика. Возможно, логин уже занят.")

if __name__ == '__main__':
    # For testing the AdminPanel independently
    app = QApplication(sys.argv)
    # This requires a dummy user_data object
    test_user_data = {"id": 1, "username": "admin_test", "role": "Administrator"}
    admin_win = AdminPanel(test_user_data)
    admin_win.show()
    sys.exit(app.exec_()) 