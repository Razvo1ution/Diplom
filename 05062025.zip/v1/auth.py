import sys
from PyQt5.QtWidgets import (QApplication, QWidget, QLabel, QLineEdit,
                             QPushButton, QVBoxLayout, QMessageBox, QRadioButton,
                             QButtonGroup, QHBoxLayout, QDialog, QFormLayout, QDialogButtonBox)
import database

class AddTeamDeveloperDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Добавить командного разработчика")
        
        layout = QFormLayout(self)
        
        self.full_name_input = QLineEdit()
        self.username_input = QLineEdit()
        self.password_input = QLineEdit()
        self.password_input.setEchoMode(QLineEdit.Password)
        
        layout.addRow("Имя:", self.full_name_input)
        layout.addRow("Логин:", self.username_input)
        layout.addRow("Пароль:", self.password_input)
        
        self.buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        self.buttons.accepted.connect(self.accept)
        self.buttons.rejected.connect(self.reject)
        
        layout.addWidget(self.buttons)

    def get_data(self):
        return {
            "full_name": self.full_name_input.text(),
            "username": self.username_input.text(),
            "password": self.password_input.text()
        }

class AuthWindow(QWidget):
    def __init__(self, main_app_callback):
        super().__init__()
        self.main_app_callback = main_app_callback
        self.setWindowTitle('Авторизация')
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()

        self.username_input = QLineEdit()
        self.username_input.setPlaceholderText('Логин')
        layout.addWidget(QLabel('Логин:'))
        layout.addWidget(self.username_input)

        self.password_input = QLineEdit()
        self.password_input.setPlaceholderText('Пароль')
        self.password_input.setEchoMode(QLineEdit.Password)
        layout.addWidget(QLabel('Пароль:'))
        layout.addWidget(self.password_input)

        login_button = QPushButton('Войти')
        login_button.clicked.connect(self.login)
        layout.addWidget(login_button)

        register_button = QPushButton('Зарегистрироваться')
        register_button.clicked.connect(self.open_registration)
        layout.addWidget(register_button)

        self.setLayout(layout)

    def login(self):
        username = self.username_input.text()
        password = self.password_input.text()
        
        if not username or not password:
            QMessageBox.warning(self, 'Ошибка', 'Пожалуйста, введите логин и пароль.')
            return
            
        user_data = database.check_user(username, password)
        
        if user_data:
            self.main_app_callback(user_data)
            self.close()
        else:
            QMessageBox.warning(self, 'Ошибка', 'Неверный логин или пароль.')

    def open_registration(self):
        self.reg_window = RegistrationWindow()
        self.reg_window.show()
        # self.close()

class RegistrationWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Регистрация')
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()

        self.full_name_input = QLineEdit()
        self.full_name_input.setPlaceholderText('Имя')
        layout.addWidget(QLabel('Имя:'))
        layout.addWidget(self.full_name_input)
        
        self.email_input = QLineEdit()
        self.email_input.setPlaceholderText('Почта')
        layout.addWidget(QLabel('Почта:'))
        layout.addWidget(self.email_input)

        self.username_input = QLineEdit()
        self.username_input.setPlaceholderText('Логин')
        layout.addWidget(QLabel('Логин:'))
        layout.addWidget(self.username_input)

        self.password_input = QLineEdit()
        self.password_input.setPlaceholderText('Пароль')
        self.password_input.setEchoMode(QLineEdit.Password)
        layout.addWidget(QLabel('Пароль:'))
        layout.addWidget(self.password_input)
        
        self.confirm_password_input = QLineEdit()
        self.confirm_password_input.setPlaceholderText('Повторите пароль')
        self.confirm_password_input.setEchoMode(QLineEdit.Password)
        layout.addWidget(QLabel('Повторите пароль:'))
        layout.addWidget(self.confirm_password_input)
        
        # Role selection
        role_layout = QHBoxLayout()
        self.role_group = QButtonGroup(self)
        
        self.admin_radio = QRadioButton("Администратор")
        self.single_dev_radio = QRadioButton("Одиночный разработчик")
        # Team developer is created by an admin, so no radio button for it here
        
        self.role_group.addButton(self.admin_radio)
        self.role_group.addButton(self.single_dev_radio)
        
        role_layout.addWidget(self.admin_radio)
        role_layout.addWidget(self.single_dev_radio)
        
        layout.addLayout(role_layout)
        self.single_dev_radio.setChecked(True) # Default role

        register_button = QPushButton('Создать аккаунт')
        register_button.clicked.connect(self.register)
        layout.addWidget(register_button)

        self.setLayout(layout)

    def register(self):
        full_name = self.full_name_input.text()
        email = self.email_input.text()
        username = self.username_input.text()
        password = self.password_input.text()
        confirm_password = self.confirm_password_input.text()

        if self.admin_radio.isChecked():
            role = "Administrator"
        else:
            role = "Single Developer"

        if not all([full_name, email, username, password, confirm_password]):
            QMessageBox.warning(self, 'Ошибка', 'Пожалуйста, заполните все поля.')
            return

        if password != confirm_password:
            QMessageBox.warning(self, 'Ошибка', 'Пароли не совпадают.')
            return

        user_id = database.create_user(full_name, email, username, password, role)

        if user_id:
            QMessageBox.information(self, 'Успех', 'Аккаунт успешно создан. Теперь вы можете войти.')
            self.close()
        else:
            QMessageBox.warning(self, 'Ошибка', 'Пользователь с таким логином или почтой уже существует.')

if __name__ == '__main__':
    # This is for testing the auth window independently
    app = QApplication(sys.argv)
    
    # You need to initialize the database tables first
    database.create_tables()

    def start_main_app(user_data):
        print(f"Starting main app for user: {user_data}")
        # In the real app, this would open the DevMetricsApp or AdminPanel
        main_window = QWidget()
        main_window.setWindowTitle(f"Welcome {user_data['role']}")
        main_window.show()
        # sys.exit(app.exec_()) # This might be tricky
    
    auth_win = AuthWindow(start_main_app)
    auth_win.show()
    sys.exit(app.exec_()) 