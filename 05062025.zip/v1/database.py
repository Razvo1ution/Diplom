import psycopg2
from psycopg2 import sql
import bcrypt
import logging
import os
from dotenv import load_dotenv

# Загружаем переменные окружения из файла .env
load_dotenv(os.path.join(os.path.dirname(__file__), '.env'))

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def create_connection():
    """Создает соединение с базой данных PostgreSQL."""
    conn = None
    try:
        conn = psycopg2.connect(
            dbname=os.getenv("DB_NAME"),
            user=os.getenv("DB_USER"),
            password=os.getenv("DB_PASSWORD"),
            host=os.getenv("DB_HOST"),
            port=os.getenv("DB_PORT")
        )
    except psycopg2.OperationalError as e:
        logging.error(f"Ошибка подключения к базе данных PostgreSQL: {e}")
    return conn

def create_tables():
    """Создает таблицы в базе данных, если они еще не существуют."""
    conn = create_connection()
    if conn is None:
        return

    users_table_sql = """
    CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        full_name TEXT NOT NULL,
        email TEXT UNIQUE,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT NOT NULL CHECK(role IN ('Administrator', 'Single Developer', 'Team Developer')),
        admin_id INTEGER,
        FOREIGN KEY(admin_id) REFERENCES users(id)
    );
    """

    daily_metrics_table_sql = """
    CREATE TABLE IF NOT EXISTS daily_metrics (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL,
        date DATE NOT NULL,
        total_time REAL,
        commits INTEGER,
        night_commits INTEGER,
        dead_periods JSONB,
        hourly_activity JSONB,
        UNIQUE(user_id, date),
        FOREIGN KEY(user_id) REFERENCES users(id)
    );
    """

    code_metrics_table_sql = """
    CREATE TABLE IF NOT EXISTS code_metrics (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL,
        commit_hash TEXT NOT NULL,
        file_path TEXT NOT NULL,
        lines_added INTEGER,
        lines_removed INTEGER,
        commit_date TIMESTAMP NOT NULL,
        UNIQUE(user_id, commit_hash, file_path),
        FOREIGN KEY(user_id) REFERENCES users(id)
    );
    """

    try:
        with conn.cursor() as cursor:
            cursor.execute(users_table_sql)
            cursor.execute(daily_metrics_table_sql)
            cursor.execute(code_metrics_table_sql)
        conn.commit()
        logging.info("Таблицы успешно созданы или уже существуют.")
    except psycopg2.Error as e:
        logging.error(f"Ошибка при создании таблиц: {e}")
    finally:
        conn.close()

def create_user(full_name, email, username, password, role, admin_id=None):
    """Создает нового пользователя в базе данных и возвращает его id."""
    hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
    
    conn = create_connection()
    if conn is None:
        return None

    sql = '''INSERT INTO users(full_name, email, username, password, role, admin_id)
             VALUES(%s, %s, %s, %s, %s, %s) RETURNING id;'''
    
    try:
        with conn.cursor() as cursor:
            cursor.execute(sql, (full_name, email, username, hashed_password.decode('utf-8'), role, admin_id))
            user_id = cursor.fetchone()[0]
            conn.commit()
            logging.info(f"Пользователь {username} успешно создан с ID {user_id}.")
            return user_id
    except psycopg2.errors.UniqueViolation:
        logging.warning(f"Пользователь с таким username или email уже существует: {username}")
        return None
    except psycopg2.Error as e:
        logging.error(f"Ошибка при создании пользователя {username}: {e}")
        return None
    finally:
        conn.close()

def check_user(username, password):
    """Проверяет учетные данные пользователя."""
    conn = create_connection()
    if conn is None:
        return None

    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT password, role, id, admin_id FROM users WHERE username = %s", (username,))
            user_data = cursor.fetchone()
        
        if user_data:
            stored_password, role, user_id, admin_id = user_data
            if bcrypt.checkpw(password.encode('utf-8'), stored_password.encode('utf-8')):
                logging.info(f"Пользователь {username} успешно аутентифицирован.")
                return {"role": role, "id": user_id, "admin_id": admin_id, "username": username}
        
        logging.warning(f"Неудачная попытка входа для пользователя {username}.")
        return None
    except psycopg2.Error as e:
        logging.error(f"Ошибка при проверке пользователя {username}: {e}")
        return None
    finally:
        if conn:
            conn.close()

def get_team_by_admin(admin_id):
    """Возвращает список разработчиков, управляемых администратором."""
    conn = create_connection()
    if conn is None: return []
    
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT id, full_name, username FROM users WHERE admin_id = %s", (admin_id,))
            team = [{'id': row[0], 'full_name': row[1], 'username': row[2]} for row in cursor.fetchall()]
        return team
    except psycopg2.Error as e:
        logging.error(f"Ошибка при получении команды для администратора {admin_id}: {e}")
        return []
    finally:
        conn.close()

def get_user_by_username(username):
    """Возвращает ID пользователя по его имени пользователя."""
    conn = create_connection()
    if conn is None:
        return None
    
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT id FROM users WHERE username = %s", (username,))
            user_id = cursor.fetchone()
            return user_id[0] if user_id else None
    except psycopg2.Error as e:
        logging.error(f"Ошибка при поиске пользователя {username}: {e}")
        return None
    finally:
        conn.close()
        
def save_daily_metric(user_id, date, total_time, commits, night_commits, dead_periods, hourly_activity):
    """Сохраняет или обновляет ежедневную метрику для пользователя."""
    conn = create_connection()
    if conn is None: return

    sql = '''INSERT INTO daily_metrics (user_id, date, total_time, commits, night_commits, dead_periods, hourly_activity)
             VALUES (%s, %s, %s, %s, %s, %s, %s)
             ON CONFLICT (user_id, date) DO UPDATE SET
                total_time = EXCLUDED.total_time,
                commits = EXCLUDED.commits,
                night_commits = EXCLUDED.night_commits,
                dead_periods = EXCLUDED.dead_periods,
                hourly_activity = EXCLUDED.hourly_activity;'''
    
    try:
        with conn.cursor() as cursor:
            cursor.execute(sql, (user_id, date, total_time, commits, night_commits, dead_periods, hourly_activity))
        conn.commit()
    except psycopg2.Error as e:
        logging.error(f"Ошибка при сохранении ежедневной метрики для пользователя {user_id}: {e}")
    finally:
        conn.close()

def save_code_metric(user_id, commit_hash, file_path, lines_added, lines_removed, commit_date):
    """Сохраняет метрику анализа кода, игнорируя дубликаты."""
    conn = create_connection()
    if conn is None: return

    sql = '''INSERT INTO code_metrics(user_id, commit_hash, file_path, lines_added, lines_removed, commit_date)
             VALUES(%s, %s, %s, %s, %s, %s)
             ON CONFLICT (user_id, commit_hash, file_path) DO NOTHING;'''

    try:
        with conn.cursor() as cursor:
            cursor.execute(sql, (user_id, commit_hash, file_path, lines_added, lines_removed, commit_date))
        conn.commit()
    except psycopg2.Error as e:
        logging.error(f"Ошибка при сохранении метрики кода для пользователя {user_id}: {e}")
    finally:
        conn.close()

def get_all_metrics_for_user(user_id):
    """Собирает все метрики для указанного пользователя из PostgreSQL."""
    conn = create_connection()
    if conn is None: return {}

    metrics = {'daily': [], 'code': []}
    
    try:
        with conn.cursor() as cursor:
            # Daily metrics
            cursor.execute("SELECT date, total_time, commits, night_commits FROM daily_metrics WHERE user_id = %s ORDER BY date DESC", (user_id,))
            metrics['daily'] = [{'date': row[0].strftime('%Y-%m-%d'), 'total_time': row[1], 'commits': row[2], 'night_commits': row[3]} for row in cursor.fetchall()]
            
            # Code metrics
            cursor.execute("SELECT commit_date, file_path, lines_added, lines_removed FROM code_metrics WHERE user_id = %s ORDER BY commit_date DESC", (user_id,))
            metrics['code'] = [{'date': row[0].strftime('%Y-%m-%d %H:%M'), 'file': row[1], 'added': row[2], 'removed': row[3]} for row in cursor.fetchall()]
            
        return metrics
    except psycopg2.Error as e:
        logging.error(f"Ошибка при получении всех метрик для пользователя {user_id}: {e}")
        return {}
    finally:
        conn.close()

def get_available_years_for_user(user_id):
    """Возвращает отсортированный список уникальных лет, за которые есть метрики у пользователя."""
    conn = create_connection()
    if conn is None: return []

    query = """
    SELECT DISTINCT EXTRACT(YEAR FROM date)::INTEGER FROM daily_metrics WHERE user_id = %s
    UNION
    SELECT DISTINCT EXTRACT(YEAR FROM commit_date)::INTEGER FROM code_metrics WHERE user_id = %s
    ORDER BY 1 DESC;
    """
    
    try:
        with conn.cursor() as cursor:
            cursor.execute(query, (user_id, user_id))
            years = [row[0] for row in cursor.fetchall()]
        return years
    except psycopg2.Error as e:
        logging.error(f"Ошибка при получении доступных лет для пользователя {user_id}: {e}")
        return []
    finally:
        conn.close()

def get_metrics_for_user_on_date(user_id, date):
    """
    Собирает метрики для указанного пользователя за конкретную дату.
    Агрегирует изменения в коде по файлам.
    """
    conn = create_connection()
    if conn is None: return {}

    metrics = {'daily': None, 'code': []}
    
    try:
        with conn.cursor() as cursor:
            # Daily metrics for the specific date
            cursor.execute(
                "SELECT date, total_time, commits, night_commits FROM daily_metrics WHERE user_id = %s AND date = %s",
                (user_id, date)
            )
            daily_result = cursor.fetchone()
            if daily_result:
                metrics['daily'] = {
                    'date': daily_result[0].strftime('%Y-%m-%d'), 
                    'total_time': daily_result[1], 
                    'commits': daily_result[2], 
                    'night_commits': daily_result[3]
                }
            
            # Aggregated code metrics for the specific date
            code_query = """
                SELECT file_path, SUM(lines_added), SUM(lines_removed)
                FROM code_metrics
                WHERE user_id = %s AND date(commit_date) = %s
                  AND file_path NOT LIKE '%%.idea/%%'
                  AND file_path NOT LIKE '%%venv/%%'
                GROUP BY file_path
                ORDER BY file_path;
            """
            cursor.execute(code_query, (user_id, date))
            metrics['code'] = [
                {'file': row[0], 'added': row[1], 'removed': row[2]} 
                for row in cursor.fetchall()
            ]
            
        return metrics
    except psycopg2.Error as e:
        logging.error(f"Ошибка при получении метрик для пользователя {user_id} на дату {date}: {e}")
        return {}
    finally:
        conn.close()

if __name__ == '__main__':
    # При первом запуске создаем таблицы
    create_tables() 